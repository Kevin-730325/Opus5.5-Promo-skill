#!/usr/bin/env python3
"""Portable renderer for circular-world-film. No generation service is called here.

The timing asset is authoritative: 25 fps, 502 frames, 38 hard-cut slots.
Both routes use that same schedule. Stills get restrained anchor-preserving push-ins;
video requires real, sufficiently long footage and never silently substitutes a still.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from fractions import Fraction
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw, ImageFont

PACKAGE = Path(__file__).resolve().parents[1]
REFERENCE_W, REFERENCE_H = 1920, 1080
DEFAULT_COPY = ["Within", "every form", "a universe", "咫尺之间", "万象自生"]
BOUNDARIES = [0,32,58,84,95,101,107,120,135,148,162,177,190,204,219,227,
              237,245,256,268,276,286,294,302,313,320,326,334,342,349,357,
              363,370,377,384,390,395,400,502]


def dump(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def resolve(root, value):
    p = Path(value).expanduser()
    return p.resolve() if p.is_absolute() else (root / p).resolve()


def executable(value, name):
    found = shutil.which(value or name) or value
    if not found or not Path(found).is_file():
        raise ValueError(f"{name} not found. Install it or pass --{name} /path/to/{name}.")
    return str(Path(found).resolve())


def run(command):
    result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors="replace")[-7000:])
    return result.stdout


def probe(path, ffprobe, frames=False):
    args = [ffprobe, "-v", "error", "-show_streams", "-show_format"]
    if frames:
        args += ["-count_frames"]
    return json.loads(run(args + ["-of", "json", str(path)]))


def video_stream(info):
    stream = next((s for s in info["streams"]
                   if s.get("codec_type") == "video" and not s.get("disposition", {}).get("attached_pic")), None)
    if stream is None:
        raise ValueError("Media has no moving-picture video stream")
    return stream


def timing(path=None):
    source = Path(path).resolve() if path else PACKAGE / "assets" / "timeline.json"
    t = read(source)
    shots = t["shots"]
    assert t["fps"] == 25 and t["total_frames"] == 502, "Timing profile was altered."
    assert len(shots) == 38, "The locked profile has exactly 38 shots."
    assert [s["start_frame"] for s in shots] + [shots[-1]["end_frame"]] == BOUNDARIES
    for i, s in enumerate(shots):
        assert s["frames"] == s["end_frame"] - s["start_frame"]
        assert s["scene_id"] == (f"scene{i+1:02d}" if i < 37 else "scene01")
    return t, source


def init_project(args):
    root = Path(args.project).expanduser().resolve()
    root.mkdir(parents=True, exist_ok=True)
    path = root / "job.json"
    if path.exists():
        raise ValueError(f"Refusing to replace existing {path}")
    for folder in ["images", "videos", "audio", "review", "exports"]:
        (root / folder).mkdir(exist_ok=True)
    reference_audio = PACKAGE / "assets" / "audio" / "reference-score.m4a"
    project_audio = root / "audio" / "reference-score.m4a"
    if not reference_audio.is_file():
        raise ValueError("The skill package is missing its default reference-score.m4a")
    if project_audio.exists() and sha(project_audio) != sha(reference_audio):
        raise ValueError(f"Refusing to overwrite a different audio file: {project_audio}")
    if not project_audio.exists():
        shutil.copy2(reference_audio, project_audio)
    t, _ = timing(args.timeline)
    subjects = {s["scene_id"]: s.get("example_subject", s.get("subject", s.get("subject_cn", ""))) for s in t["shots"]}
    job = {
        "schema_version": 1,
        "title": "Circular Worlds",
        "mode": args.mode,
        "copy": DEFAULT_COPY,
        "fonts": {"latin": None, "cjk": None},
        "title_overlays": {},
        "audio": {"path": "audio/reference-score.m4a", "start_offset_seconds": 0, "source": "reference"},
        "scenes": [
            {"scene_id": f"scene{i:02d}", "subject": subjects.get(f"scene{i:02d}", ""),
             "image": f"images/scene{i:02d}.png", "video": f"videos/scene{i:02d}.mp4",
             "source_offset_seconds": 0, "zoom_start": 1.0, "zoom_end": 1.025,
             "video_zoom": 1.0, "anchor": [0.5, 0.52], "polarity": "template"}
            for i in range(1, 38)
        ],
        "shot_overrides": {},
        "notes": "Fill paths with approved assets. Never change the locked timing. Default text uses bundled raster title layers; custom copy requires explicit local font files."
    }
    dump(path, job)
    print(path)


def load_job(args):
    path = Path(args.job).expanduser().resolve()
    job = read(path)
    if job.get("mode") not in ("stills", "video"):
        raise ValueError("job.mode must be stills or video")
    copy = job.get("copy", DEFAULT_COPY)
    if not isinstance(copy, list) or len(copy) != 5 or not all(isinstance(x, str) and x.strip() for x in copy):
        raise ValueError("job.copy must contain exactly five non-empty phrases")
    job["copy"] = copy
    scenes = job.get("scenes", [])
    ids = [s.get("scene_id") for s in scenes]
    if len(ids) != 37 or set(ids) != {f"scene{i:02d}" for i in range(1, 38)}:
        raise ValueError("Provide exactly 37 unique scene01…scene37 objects; ending reuses scene01 automatically")
    t, timeline_file = timing(args.timeline)
    return job, path, t, timeline_file


def build_plan(job, job_path, t, require_media=False, ffprobe=None):
    root = job_path.parent
    scenes = {s["scene_id"]: s for s in job["scenes"]}
    result = []
    problems = []
    for i, slot in enumerate(t["shots"]):
        scene = dict(scenes[slot["scene_id"]])
        override = job.get("shot_overrides", {}).get(str(i + 1), {})
        if set(override) - {"source_offset_seconds", "zoom_start", "zoom_end", "video_zoom", "anchor", "polarity"}:
            raise ValueError(f"Shot {i+1}: overrides may change framing/source window, never timing or scene identity")
        scene.update(override)
        path = resolve(root, scene["image" if job["mode"] == "stills" else "video"])
        offset = float(scene.get("source_offset_seconds", 0))
        anchor = scene.get("anchor", [0.5, 0.52])
        if offset < 0 or len(anchor) != 2 or not all(0 <= float(x) <= 1 for x in anchor):
            raise ValueError(f"Shot {i+1}: invalid offset/anchor")
        if scene.get("polarity", "template") not in ("template", "ivory", "ink"):
            raise ValueError(f"Shot {i+1}: polarity must be template, ivory, or ink")
        for key in ["zoom_start", "zoom_end", "video_zoom"]:
            if not 1 <= float(scene.get(key, 1)) <= 1.5:
                raise ValueError(f"Shot {i+1}: {key} must be in [1, 1.5]")
        row = {**slot, "shot": i + 1, "source": str(path), "exists": path.is_file(),
               "mode": job["mode"], "framing": scene, "source_offset_seconds": offset,
               "duration_seconds": slot["frames"] / 25}
        if not path.is_file():
            problems.append(f"shot {i+1}: missing {path}")
        elif require_media:
            if job["mode"] == "stills":
                with Image.open(path) as im:
                    im.load()
                    row["source_size"] = list(im.size)
            else:
                info = probe(path, ffprobe)
                stream = video_stream(info)
                duration = float(stream.get("duration", info["format"].get("duration", 0)))
                row["source_duration_seconds"] = duration
                if offset + row["duration_seconds"] > duration + 0.001:
                    problems.append(f"shot {i+1}: source needs {offset + row['duration_seconds']:.3f}s, available {duration:.3f}s; choose another window or regenerate, no freeze-frame padding")
        result.append(row)
    return {"fps": 25, "total_frames": 502, "duration_seconds": 20.08,
            "mode": job["mode"], "shots": result, "problems": problems,
            "source_timing": "locked profile; integer frames; intervals [start,end)"}


def font_mask(text, size, font_file, seed, curve):
    """The approved 3x raster, stable ink gaps, coarse modulation, and curved baseline."""
    font = ImageFont.truetype(str(font_file), round(size * 3))
    box = font.getbbox(text)
    pad = 18
    mask = Image.new("L", (box[2]-box[0]+pad*2, box[3]-box[1]+pad*2), 0)
    ImageDraw.Draw(mask).text((pad-box[0], pad-box[1]), text, font=font, fill=255)
    mask = mask.resize((round(mask.width/3), round(mask.height/3)), Image.Resampling.LANCZOS)
    a = np.asarray(mask).astype(np.float32)
    rng = np.random.default_rng(seed)
    noise = rng.random(a.shape)
    a *= np.where(noise < .018, .24, np.where(noise < .07, .78, 1.0))
    coarse = Image.fromarray(rng.integers(185,255,(max(2,a.shape[0]//7),max(2,a.shape[1]//7)),dtype=np.uint8))
    coarse = np.asarray(coarse.resize((a.shape[1],a.shape[0]),Image.Resampling.BICUBIC))/255
    a *= .87 + .13*coarse
    if curve:
        bend = max(4, round(a.shape[1]*.031))
        warped = np.zeros((a.shape[0]+bend,a.shape[1]),np.float32)
        for x in range(a.shape[1]):
            dy = round(bend*((2*x/max(a.shape[1]-1,1)-1)**2))
            warped[dy:dy+a.shape[0],x] = a[:,x]
        a = warped
    mask = Image.fromarray(a.astype(np.uint8))
    return mask.crop(mask.getbbox())


def custom_font(job, job_path, text):
    # Curly apostrophes and em dashes are Latin typography, not a reason to switch fonts.
    is_cjk = any(0x2e80 <= ord(c) <= 0xa4cf or 0xac00 <= ord(c) <= 0xd7af
                 or 0xf900 <= ord(c) <= 0xfaff or 0x20000 <= ord(c) <= 0x3134f for c in text)
    key = "cjk" if is_cjk else "latin"
    value = job.get("fonts", {}).get(key)
    if not value:
        raise ValueError(f"Custom {key} copy requires job.fonts.{key}: provide a licensed local font file. No silent font substitution is performed.")
    path = resolve(job_path.parent, value)
    if not path.is_file():
        raise ValueError(f"Font does not exist: {path}")
    return path


def tint(image, polarity, closing=False):
    color = (247,241,225) if closing else ((247,241,222) if polarity == "ivory" else (26,25,22))
    result = Image.new("RGBA", image.size, color + (0,))
    result.putalpha(image.getchannel("A"))
    return result


def make_titles(job, job_path, t, out_size):
    result = {}
    for i, s in enumerate(t["shots"]):
        j = s.get("title_index")
        if j is None:
            continue
        phase = 0 if j < 5 else 1 if j < 10 else 2
        text = job["copy"][phase]
        replacement = job.get("title_overlays", {}).get(str(i+1))
        if replacement:
            p = resolve(job_path.parent,replacement)
            im = Image.open(p)
            if im.mode != "RGBA" or im.size != (REFERENCE_W,REFERENCE_H):
                raise ValueError(f"Shot {i+1}: replacement title must be a 1920×1080 RGBA PNG with transparency")
            if im.getchannel("A").getextrema()[0] != 0 or im.getchannel("A").getbbox() is None:
                raise ValueError(f"Shot {i+1}: title layer must have a transparent background and visible glyphs")
            im = im.copy()
        elif text == DEFAULT_COPY[phase]:
            path = PACKAGE/"assets"/"titles"/f"shot{i+1:02d}.png"
            if not path.is_file():
                raise ValueError(f"Missing bundled title {path.name}; reinstall the complete skill package")
            im = Image.open(path).convert("RGBA")
        else:
            spec = s.get("typography") or {}
            size = float(spec.get("font_size", 88 if phase==0 else 130 if phase==1 else 170))
            f = custom_font(job, job_path, text)
            mask = font_mask(text,size,f,900+j,True)
            if mask.width > REFERENCE_W * .86:
                raise ValueError(f"Shot {i+1}: custom phrase is too wide at the locked typography size; shorten it or provide an explicitly reviewed replacement title layer")
            tile = Image.new("RGBA",mask.size,(247,241,222,0)); tile.putalpha(mask)
            im = Image.new("RGBA",(REFERENCE_W,REFERENCE_H))
            im.alpha_composite(tile,((REFERENCE_W-mask.width)//2,530-mask.height))
            im = tint(im,spec.get("polarity","ivory"))
        result[i] = im.resize(out_size,Image.Resampling.LANCZOS)
    for number in [1,2]:
        text = job["copy"][number+2]
        replacement = job.get("title_overlays", {}).get(f"closing{number}")
        if replacement:
            tile = Image.open(resolve(job_path.parent,replacement))
            if tile.mode != "RGBA":
                raise ValueError("Closing replacement title must be a tightly cropped transparent RGBA PNG")
            if tile.getchannel("A").getextrema()[0] != 0 or tile.getchannel("A").getbbox() is None:
                raise ValueError("Closing title layer must have a transparent background and visible glyphs")
            tile = tile.copy()
        elif text == DEFAULT_COPY[number+2]:
            p = PACKAGE/"assets"/"titles"/f"closing{number:02d}.png"
            if not p.is_file():
                raise ValueError(f"Missing bundled title {p.name}")
            tile = Image.open(p).convert("RGBA")
        else:
            mask = font_mask(text,86,custom_font(job,job_path,text),449+number,False)
            tile = Image.new("RGBA",mask.size,(247,241,225,0));tile.putalpha(mask)
        if tile.width > REFERENCE_W*.86:
            raise ValueError("Closing phrase is too wide; use a shorter phrase")
        result[f"closing{number}"] = tile.resize((max(1,round(tile.width*out_size[0]/REFERENCE_W)),max(1,round(tile.height*out_size[1]/REFERENCE_H))),Image.Resampling.LANCZOS)
    return result


def fit(im, size, zoom=1., anchor=(.5,.52)):
    w,h = size
    scale = max(w/im.width,h/im.height)*zoom
    sw,sh = max(w,round(im.width*scale)),max(h,round(im.height*scale))
    im = im.resize((sw,sh),Image.Resampling.LANCZOS)
    x = round((sw-w)*anchor[0]); y = round((sh-h)*anchor[1])
    return im.crop((x,y,x+w,y+h))


def add_grain(im, seed, amount):
    if not amount:
        return im
    a = np.asarray(im).astype(np.int16)
    noise = np.random.default_rng(seed).normal(0,amount,(im.height,im.width,1)).astype(np.int16)
    return Image.fromarray(np.clip(a+noise,0,255).astype(np.uint8))


def encoder(ffmpeg, target, size, frames, crf):
    w,h = size
    return subprocess.Popen([ffmpeg,"-v","error","-f","rawvideo","-pix_fmt","rgb24","-s",f"{w}x{h}","-r","25","-i","-",
        "-an","-frames:v",str(frames),"-vf",f"scale={w}:{h}:out_color_matrix=bt709:out_range=tv,format=yuv420p",
        "-c:v","libx264","-preset","fast","-crf",str(crf),"-pix_fmt","yuv420p","-colorspace","bt709",
        "-color_primaries","bt709","-color_trc","bt709","-color_range","tv","-threads","2","-y",str(target)],
        stdin=subprocess.PIPE,stderr=subprocess.PIPE)


def finish(process):
    process.stdin.close()
    error = process.stderr.read().decode(errors="replace")
    process.wait()
    if process.returncode:
        raise RuntimeError(error)


def read_exact(pipe, count):
    data = bytearray()
    while len(data)<count:
        block = pipe.read(count-len(data))
        if not block:
            break
        data.extend(block)
    return bytes(data)


def video_frames(row, ffmpeg, size):
    w,h = size; n = row["frames"]
    command = [ffmpeg,"-v","error","-ss",str(row["source_offset_seconds"]),"-i",row["source"],"-an",
               "-vf",f"fps=25,scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,crop={w}:{h},setsar=1",
               "-frames:v",str(n),"-pix_fmt","rgb24","-f","rawvideo","-"]
    pipe = subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    try:
        for k in range(n):
            raw = read_exact(pipe.stdout,w*h*3)
            if len(raw)!=w*h*3:
                raise RuntimeError(f"Shot {row['shot']}: only {k}/{n} moving frames decoded. No freeze-frame substitution.")
            yield Image.frombytes("RGB",size,raw)
        error = pipe.stderr.read().decode(errors="replace")
        pipe.wait()
        if pipe.returncode:
            raise RuntimeError(error)
    finally:
        if pipe.poll() is None:
            pipe.kill();pipe.wait()


def closing_rise(t, frame):
    keys = t["closing"]["keyframes"]
    return float(np.interp(frame,[k["frame"] for k in keys],[k["rise_px"] for k in keys]))


def process_shot(row, job, t, titles, ffmpeg, size, target, review_dir, crf):
    i = row["shot"]-1; n=row["frames"]; scene=row["framing"]
    if job["mode"] == "stills":
        original = Image.open(row["source"]).convert("RGB")
        frames = (original for _ in range(n))
    else:
        frames = video_frames(row,ffmpeg,size)
    main = titles.get(i)
    if main is not None:
        pol = scene.get("polarity","template")
        if pol != "template":
            main = tint(main,pol)
    pipe = encoder(ffmpeg,target,size,n,crf)
    source_first=source_last=None
    w,h=size; scale_y=h/REFERENCE_H
    try:
        for f, raw in enumerate(frames):
            a=np.asarray(raw.resize((160,90),Image.Resampling.BILINEAR),dtype=np.float32)
            if source_first is None:source_first=a
            source_last=a
            progress=f/max(n-1,1)
            z=(float(scene.get("zoom_start",1))+(float(scene.get("zoom_end",1.025))-float(scene.get("zoom_start",1)))*progress) if job["mode"]=="stills" else float(scene.get("video_zoom",1))
            pic=fit(raw,size,z,scene.get("anchor",[.5,.52]))
            if i==37:
                rise=closing_rise(t,row["start_frame"]+f)
                shift=round((730-rise)*scale_y)
                a=np.asarray(pic); bg=np.empty_like(a)
                bg[:]=np.mean(a[:max(1,round(24*scale_y))],axis=(0,1)).astype(np.uint8)
                if shift>=0 and shift<h:bg[shift:]=a[:h-shift]
                elif shift<0 and -shift<h:bg[:h+shift]=a[-shift:]
                pic=add_grain(Image.fromarray(bg),71000+f,1.25).convert("RGBA")
                tile=titles["closing1" if row["start_frame"]+f<t["closing"]["switch_frame"] else "closing2"]
                pic.alpha_composite(tile,((w-tile.width)//2,round((462-rise)*scale_y)))
            else:
                pic=add_grain(pic,23000+max(0,i-14)*70+f,2.1 if i>=14 else 0).convert("RGBA")
                if main is not None:pic.alpha_composite(main)
            if f==n//2:
                pic.convert("RGB").save(review_dir/f"shot{row['shot']:02d}.jpg",quality=92)
            pipe.stdin.write(pic.convert("RGB").tobytes())
        finish(pipe)
    except Exception:
        pipe.kill();pipe.wait()
        raise
    return {"shot":row["shot"],"scene_id":row["scene_id"],"start_frame":row["start_frame"],"end_frame":row["end_frame"],
            "frames":n,"clip":str(target),"source":row["source"],"source_offset_seconds":row["source_offset_seconds"],
            "source_first_last_mae_before_editorial_grain":float(np.mean(np.abs(source_last-source_first))),
            "motion_note":"Metric is diagnostic, not proof of correct physical motion; inspect the selected window."}


def contact(review_dir):
    paths=sorted(review_dir.glob("shot??.jpg"))
    canvas=Image.new("RGB",(1280,math.ceil(len(paths)/4)*205),(18,21,25))
    draw=ImageDraw.Draw(canvas)
    for i,p in enumerate(paths):
        x=(i%4)*320;y=(i//4)*205
        im=Image.open(p).convert("RGB");im.thumbnail((312,176),Image.Resampling.LANCZOS)
        canvas.paste(im,(x+4,y));draw.text((x+8,y+181),p.stem,fill=(235,235,235))
    path=review_dir/"contact_sheet.jpg";canvas.save(path,quality=90)
    return path


def verify_file(path, ffprobe, manifest=None, allow_silent=False):
    info=probe(path,ffprobe,True);s=video_stream(info)
    count=int(s.get("nb_read_frames",s.get("nb_frames",-1)))
    rate=Fraction(s["avg_frame_rate"])
    raw=json.loads(run([ffprobe,"-v","error","-select_streams",str(s["index"]),"-show_frames","-show_entries","frame=best_effort_timestamp_time","-of","json",str(path)]))
    pts=[float(q["best_effort_timestamp_time"]) for q in raw["frames"]]
    exact_pts=len(pts)==502 and all(abs(v-i/25)<.00001 for i,v in enumerate(pts))
    m=read(manifest) if manifest else None
    silent_preview=bool(m.get("silent_preview",False)) if m else allow_silent
    audio_streams=[q for q in info["streams"] if q.get("codec_type")=="audio"]
    audio_coverage=[]
    for a in audio_streams:
        start=float(a.get("start_time",0))
        duration=float(a.get("duration",0))
        audio_coverage.append({"start_seconds":start,"duration_seconds":duration,
                               "end_seconds":start+duration,
                               "covers_program":start<=0.001 and start+duration>=20.079})
    audio_ok=bool(audio_coverage) and all(a["covers_program"] for a in audio_coverage)
    report={"file":str(Path(path).resolve()),"sha256":sha(path),"frames":count,"fps":str(rate),
            "width":s["width"],"height":s["height"],"duration_seconds":float(s["duration"]),
            "all_frame_pts_match_locked_25fps_schedule":exact_pts,
            "audio_streams":len(audio_streams),"audio_coverage":audio_coverage,
            "silent_preview_allowed":silent_preview,
            "audio_requirement_passed":audio_ok or (silent_preview and not audio_streams),
            "passed":count==502 and rate==25 and exact_pts and abs(float(s["duration"])-20.08)<.00001
                      and (audio_ok or (silent_preview and not audio_streams))}
    if manifest:
        boundaries=[x["start_frame"] for x in m["shots"]]+[m["shots"][-1]["end_frame"]]
        report["manifest_cut_frames_match"]=boundaries==BOUNDARIES
        report["passed"] &= report["manifest_cut_frames_match"]
        checks=[]
        for row in m["shots"]:
            cp=Path(row["clip"])
            cs=video_stream(probe(cp,ffprobe,True))
            actual=int(cs.get("nb_read_frames",-1))
            checks.append({"shot":row["shot"],"expected_frames":row["frames"],"actual_frames":actual,"passed":actual==row["frames"]})
        report["clip_frame_checks"]=checks
        report["passed"] &= all(x["passed"] for x in checks)
    report["visual_review_required"]="Check identities, arc registration, real motion, text texture/legibility and musical synchronization. Structural verification cannot judge aesthetics."
    return report


def render(args):
    ff=executable(args.ffmpeg,"ffmpeg");fp=executable(args.ffprobe,"ffprobe")
    job,jp,t,tp=load_job(args)
    size=(args.width,args.height)
    if min(size)<64 or any(x%2 for x in size) or size[0]*9!=size[1]*16:
        raise ValueError("Output must be an even-pixel 16:9 raster, e.g. 1920×1080 or preview 640×360")
    out=Path(args.output).expanduser().resolve()
    if out.exists() and not args.overwrite:raise ValueError(f"Output exists: {out}; use --overwrite only intentionally")
    plan=build_plan(job,jp,t,True,fp)
    if plan["problems"]:raise ValueError("\n".join(plan["problems"]))
    titles=make_titles(job,jp,t,size)
    audio=job.get("audio",{});audio_path=resolve(jp.parent,audio["path"]) if audio.get("path") else None
    if not audio_path and not args.silent_preview:
        raise ValueError("Final output needs job.audio.path. Use --silent-preview only for a clearly labelled picture preview.")
    offset=float(audio.get("start_offset_seconds",0))
    if offset<0:raise ValueError("Audio offset must be nonnegative")
    reference_audio=audio.get("source")=="reference" and audio_path is not None
    if reference_audio:
        if offset!=0:
            raise ValueError("The locked reference score starts at zero. Use source=custom for an intentionally different cue.")
        bundled=PACKAGE/"assets"/"audio"/"reference-score.m4a"
        if not bundled.is_file() or sha(audio_path)!=sha(bundled):
            raise ValueError("source=reference must use the bundled unmodified score; choose source=custom for other music")
    if audio_path:
        ai=probe(audio_path,fp)
        ast=next((x for x in ai["streams"] if x.get("codec_type")=="audio"),None)
        if not ast:raise ValueError("Selected audio source has no audio stream")
        if reference_audio and ast.get("codec_name")!="aac":raise ValueError("Bundled reference score must be AAC for lossless packet copying")
        dur=float(ast.get("duration",ai["format"].get("duration",0)))
        if dur+0.001<offset+20.08:raise ValueError("Audio is shorter than the locked program; provide an aligned full-length cue")
    out.parent.mkdir(parents=True,exist_ok=True)
    work=out.parent/(out.stem+"_work");clips=work/"clips";review=work/"review"
    clips.mkdir(parents=True,exist_ok=True);review.mkdir(exist_ok=True)
    dump(work/"plan.json",plan)
    records=[]
    for row in plan["shots"]:
        target=clips/f"{row['shot']:02d}.mp4"
        records.append(process_shot(row,job,t,titles,ff,size,target,review,args.crf))
        print(f"Rendered {row['shot']:02d}/38 ({row['frames']} frames)",flush=True)
    listing=work/"concat.txt"
    listing.write_text("".join("file '"+r["clip"].replace("'","'\\''")+"'\n" for r in records),encoding="utf-8")
    picture=work/"picture.mp4"
    run([ff,"-v","error","-f","concat","-safe","0","-i",str(listing),"-map","0:v:0","-c","copy","-an","-y",str(picture)])
    if audio_path:
        audio_codec=["-c:a","copy"] if reference_audio else ["-c:a","aac","-b:a","320k","-ar","48000"]
        audio_input=["-i",str(audio_path)] if reference_audio else ["-ss",str(offset),"-i",str(audio_path)]
        run([ff,"-v","error","-i",str(picture)]+audio_input+["-map","0:v:0","-map","1:a:0",
             "-c:v","copy"]+audio_codec+["-t","20.08","-movflags","+faststart","-y",str(out)])
    else:
        run([ff,"-v","error","-i",str(picture),"-map","0:v:0","-c","copy","-movflags","+faststart","-y",str(out)])
    manifest={"created_at":datetime.now(timezone.utc).isoformat(),"mode":job["mode"],"fps":25,"total_frames":502,"duration_seconds":20.08,
              "output":str(out),"output_size":list(size),"silent_preview":not bool(audio_path),"audio":str(audio_path) if audio_path else None,
              "audio_start_offset_seconds":offset,"job_sha256":sha(jp),"timeline_sha256":sha(tp),"copy":job["copy"],"shots":records,
              "audio_source":audio.get("source","custom"),"audio_render_mode":"stream_copy_aac" if reference_audio else "encode_aac" if audio_path else "silent_preview",
              "contact_sheet":str(contact(review))}
    manifest_path=work/"render_manifest.json";dump(manifest_path,manifest)
    validation=verify_file(out,fp,manifest_path);dump(work/"verification.json",validation)
    if not validation["passed"]:raise RuntimeError("Rendered output failed timing validation; see verification.json")
    print(json.dumps({"video":str(out),"manifest":str(manifest_path),"verification":str(work/"verification.json"),"silent_preview":not bool(audio_path)},ensure_ascii=False))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    sub=parser.add_subparsers(dest="command",required=True)
    p=sub.add_parser("init",help="Create an editable project job, without generating media")
    p.add_argument("--project",required=True);p.add_argument("--mode",choices=["stills","video"],default="stills");p.add_argument("--timeline")
    p=sub.add_parser("plan",help="Build the exact frame schedule and identify missing source media")
    p.add_argument("--job",required=True);p.add_argument("--timeline");p.add_argument("--output");p.add_argument("--require-media",action="store_true");p.add_argument("--ffprobe")
    p=sub.add_parser("render",help="Render all 38 shots, retained typography and closing movement")
    p.add_argument("--job",required=True);p.add_argument("--output",required=True);p.add_argument("--timeline");p.add_argument("--ffmpeg");p.add_argument("--ffprobe")
    p.add_argument("--width",type=int,default=1920);p.add_argument("--height",type=int,default=1080);p.add_argument("--crf",type=int,default=16)
    p.add_argument("--silent-preview",action="store_true");p.add_argument("--overwrite",action="store_true")
    p=sub.add_parser("verify",help="Check actual output frame count, PTS and optional clip boundaries")
    p.add_argument("--video",required=True);p.add_argument("--manifest");p.add_argument("--output");p.add_argument("--ffprobe");p.add_argument("--allow-silent",action="store_true",help="Validate a deliberately silent picture preview without a render manifest")
    args=parser.parse_args()
    try:
        if args.command=="init":init_project(args)
        elif args.command=="render":render(args)
        elif args.command=="plan":
            job,jp,t,_=load_job(args)
            fp=executable(args.ffprobe,"ffprobe") if args.require_media else None
            plan=build_plan(job,jp,t,args.require_media,fp)
            if args.output:dump(args.output,plan)
            print(json.dumps(plan,ensure_ascii=False,indent=2))
            if args.require_media and plan["problems"]:return 2
        elif args.command=="verify":
            report=verify_file(Path(args.video),executable(args.ffprobe,"ffprobe"),args.manifest,args.allow_silent)
            if args.output:dump(args.output,report)
            print(json.dumps(report,ensure_ascii=False,indent=2))
            if not report["passed"]:return 2
    except (ValueError,RuntimeError,AssertionError,FileNotFoundError) as exc:
        print(f"ERROR: {exc}",file=sys.stderr);return 2
    return 0


if __name__=="__main__":
    raise SystemExit(main())
