#!/usr/bin/env python3
"""Create provider-ready prompt batches from a resolved brief and 37 scene concepts.

No generation, network access or credential reading occurs here. The cultural and
aesthetic decisions belong in the scene bank; this script preserves the common
composition and exact edit requirements while exporting them consistently.
"""
from pathlib import Path
import argparse
import json
import shutil
import sys

PACKAGE = Path(__file__).resolve().parents[1]
COMPOSITION = (
    "One original full-bleed 16:9 landscape photographic first frame. "
    "One monumental broad shallow CONVEX curved edge, with its highest apex "
    "near x50%, y54% and both sides descending toward y68-72%. Material fills "
    "the lower area and continues beyond the left, right and bottom edges. "
    "The upper 40-50% is quiet, uninterrupted negative space. Use a very close "
    "low/tangent view or appropriate cropped macro/telephoto view, not a complete "
    "little object centered in the frame. "
)
MATERIAL_STYLE = (
    "Tactile late-1960s/1970s editorial "
    "macro photography, credible material microstructure, controlled grazing "
    "light, fine analog film grain, restrained halation and slightly imperfect "
    "photographic print color. Rich varied material color with clean separation "
    "from the upper field. No modern glossy CGI, no artificial neon, no generic "
    "oil-painting filter. No added captions, logos, watermarks, UI, borders or "
    "contact sheets. Existing lettering physically integral to a specified "
    "artifact may remain accurate; never invent decorative pseudo-writing. "
)
MOTION = (
    "Animate the approved supplied first frame. Movement begins immediately "
    "and is continuously visible, restrained and physically plausible. Preserve "
    "the exact broad low convex anchor, composition, palette, textures and quiet "
    "upper background. Keep rigid materials and architecture rigid. Fine tactile "
    "analog grain. Do not reveal the whole object, morph materials, add patterns, "
    "objects, lettering or text. One continuous take; no cuts or transitions."
)

def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def dump(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def build(brief, bank, project):
    for key in ("theme", "concept"):
        if not isinstance(brief.get(key), str) or not brief[key].strip():
            raise ValueError(f"Resolve brief.{key} before writing generation prompts")
    if brief.get("route") not in ("stills", "video"):
        raise ValueError("brief.route must be stills or video")
    brief_status = brief.get("brief_status", "draft")
    if brief_status not in ("draft", "ready"):
        raise ValueError("brief.brief_status must be draft or ready")
    audio_source = brief.get("audio_source", "custom" if brief.get("audio_path") else "reference")
    if audio_source not in ("reference", "custom"):
        raise ValueError("brief.audio_source must be reference or custom")
    if audio_source == "custom" and not brief.get("audio_path"):
        raise ValueError("Custom music requires brief.audio_path")
    copy = brief.get("copy", {})
    if len(copy.get("main", [])) != 3 or len(copy.get("ending", [])) != 2:
        raise ValueError("Copy must have three main phrases and two ending phrases")
    if any(not isinstance(x, str) or not x.strip() for x in copy["main"] + copy["ending"]):
        raise ValueError("Every copy phrase must be non-empty")
    rows = bank.get("scenes") if isinstance(bank, dict) else bank
    if not isinstance(rows, list):
        raise ValueError("Scene bank must contain a scenes list")
    expected = [f"scene{i:02d}" for i in range(1, 38)]
    ids = [r.get("scene_id") for r in rows]
    if len(ids) != 37 or len(set(ids)) != 37 or set(ids) != set(expected):
        raise ValueError("Exactly scene01..scene37 required, with no duplicates")
    rows = sorted(rows, key=lambda r: r["scene_id"])
    timeline = load(PACKAGE / "assets/timeline.json")
    slots = {x["scene_id"]: x for x in timeline["shots"][:37]}
    job_path = project / "job.json"
    render_job = load(job_path) if job_path.exists() else None
    if render_job is not None and [s.get("scene_id") for s in render_job.get("scenes", [])] != expected:
        raise ValueError("Existing render job does not have the expected scene01..scene37 sequence")
    jobs, video_jobs, review = [], [], []
    avoid = brief.get("avoid", [])
    for r in rows:
        sid = r["scene_id"]
        required = ("subject", "material_detail", "background", "light", "motion", "concept_reason")
        for key in required:
            if not isinstance(r.get(key), str) or not r[key].strip():
                raise ValueError(f"{sid}.{key} must be resolved by the agent/user")
        source_note = r.get("source_notes", "")
        context = (f"Theme: {brief['theme']}. Concept: {brief['concept']}. "
                   f"Cultural/regional scope: {brief.get('culture_region_period', '')}. ")
        detail = (f"Subject: {r['subject']}. {r['material_detail']} "
                  f"Upper background: {r['background']}. Light: {r['light']}. ")
        exception = r.get("composition_exception", "")
        composition = COMPOSITION
        if exception:
            composition = ("One original full-bleed 16:9 landscape photographic first frame. "
                           f"Intentional geometry exception: {exception}. Preserve the subject's genuine "
                           "geometry and a low visual anchor; keep the upper field quiet for type. "
                           "Do not warp a flat tool, diagram or counting device into a convex dome. ")
        prompt = context + detail + composition + MATERIAL_STYLE
        if avoid:
            prompt += "Additional exclusions: " + "; ".join(map(str, avoid)) + "."
        motion_style = MOTION.replace("exact broad low convex anchor", "specified low geometric anchor") if exception else MOTION
        video = r["motion"].strip() + " " + motion_style
        required_frames = max(s["frames"] for s in timeline["shots"] if s["scene_id"] == sid)
        image_path, video_path = f"images/{sid}.png", f"videos/{sid}.mp4"
        has_ready_video = brief["route"] == "video" and bool(r.get("provided_video"))
        jobs.append({"scene_id": sid, "subject": r["subject"], "image_prompt": prompt,
                     "video_prompt": video, "output_image": image_path, "output_video": video_path,
                     "provided_image": r.get("provided_image"), "provided_video": r.get("provided_video"),
                     "skip_generation": bool(r.get("provided_image")) or has_ready_video,
                     "concept_reason": r["concept_reason"], "source_notes": source_note})
        video_jobs.append({"scene_id": sid, "kind": "image_to_video", "input_image": r.get("provided_image") or image_path,
                           "motion_prompt": video, "aspect_ratio": "16:9", "requested_resolution": "1080p",
                           "requested_duration_seconds": 5 if sid == "scene01" else 4,
                           "duration_policy": "Use the shortest supported duration covering the clean required window; do not invent unsupported values.",
                           "minimum_edit_window_seconds": required_frames / 25,
                           "target_edit_frames": required_frames, "target_fps": 25,
                           "output_video": video_path})
        review.append(f"## {sid} — {r['subject']}\n\nSlot role: {slots[sid]['role']}. "
                      f"Concept: {r['concept_reason']}\n\nSources: {source_note or 'Agent/user must resolve cultural claims.'}\n\n"
                      f"### Image\n\n{prompt}\n\n### Video\n\n{video}\n")
    video_jobs = [v for v, r in zip(video_jobs, rows) if brief["route"] == "video" and not r.get("provided_video")]
    project.mkdir(parents=True, exist_ok=True)
    for folder in ("images", "videos", "audio", "review", "exports"):
        (project / folder).mkdir(exist_ok=True)
    if audio_source == "reference":
        bundled_audio = PACKAGE / "assets/audio/reference-score.m4a"
        target_audio = project / "audio/reference-score.m4a"
        if not target_audio.exists():
            shutil.copy2(bundled_audio, target_audio)
        elif target_audio.read_bytes() != bundled_audio.read_bytes():
            raise ValueError("audio/reference-score.m4a differs from the bundled score; preserve it under a custom name before proceeding")
        audio = {"path": "audio/reference-score.m4a", "start_offset_seconds": 0, "source": "reference"}
    else:
        audio = {"path": brief["audio_path"], "start_offset_seconds": brief.get("audio_offset_s", 0), "source": "custom"}
    image_plan = {"brief_status": brief_status,
                  "provider": brief.get("image_provider", "discover_available"),
                  "model": brief.get("image_model", "discover_available"),
                  "size": brief.get("image_size", "2048x1152"),
                  "quality": brief.get("image_quality", "medium"),
                  "max_attempts_per_scene": brief.get("max_attempts_per_scene", 2),
                  "paid_generation_approved": brief_status == "ready" and bool(brief.get("generation_authorized", False)),
                  "budget_usd": brief.get("budget_usd"),
                  "cost_ceiling_usd_per_request": brief.get("cost_ceiling_usd_per_request"),
                  "jobs": [j for j in jobs if not j["skip_generation"]]}
    dump(project / "image_jobs.json", image_plan)
    dump(project / "all_scenes.json", {"theme": brief["theme"], "brief_status": brief_status, "jobs": jobs})
    dump(project / "video_jobs.json", {"brief_status": brief_status,
                                       "paid_generation_approved": brief_status == "ready" and bool(brief.get("generation_authorized", False)),
                                       "provider": brief.get("video_provider", "discover_available"),
                                       "model": brief.get("video_model", "discover_available"),
                                       "enabled": brief["route"] == "video",
                                       "jobs": video_jobs})
    (project / "prompts.md").write_text(f"# Circular World Film · {brief_status} prompt batch\n\n" + "\n".join(review), encoding="utf-8")
    if render_job is not None:
        render_job["mode"] = brief["route"]
        render_job["brief_status"] = brief_status
        if "copy_status" in brief:
            render_job["copy_status"] = brief["copy_status"]
        if "ending_options" in brief:
            render_job["ending_options"] = brief["ending_options"]
        render_job["copy"] = copy["main"] + copy["ending"]
        render_job["audio"] = audio
        for target, r, j in zip(render_job["scenes"], rows, jobs):
            target["subject"] = r["subject"]
            target["image"] = r.get("provided_image") or j["output_image"]
            target["video"] = r.get("provided_video") or j["output_video"]
            if "polarity" in r:
                target["polarity"] = r["polarity"]
        dump(job_path, render_job)
    return {"scene_count": 37, "new_image_jobs": len(image_plan["jobs"]), "video_jobs": len(video_jobs),
            "render_job_updated": job_path.exists(), "project": str(project)}

def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--brief", required=True, type=Path)
    ap.add_argument("--bank", required=True, type=Path)
    ap.add_argument("--project", required=True, type=Path)
    args = ap.parse_args()
    try:
        print(json.dumps(build(load(args.brief), load(args.bank), args.project.resolve()), ensure_ascii=False, indent=2))
    except (OSError, ValueError, KeyError, TypeError) as e:
        print(f"Prompt preparation stopped: {e}", file=sys.stderr)
        return 1
    return 0

if __name__ == "__main__":
    sys.exit(main())
