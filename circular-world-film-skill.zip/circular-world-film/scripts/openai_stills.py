#!/usr/bin/env python3
"""Explicitly authorized text-to-image batches via the official OpenAI Images API.

No third-party dependencies. Dry-run is the default and never reads a key or calls
the network. Use a provider-supported, verified per-request cost ceiling; this
ledger reserves that ceiling, it is not an invoice or an API-enforced spend cap.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import math
import os
from pathlib import Path
import re
import struct
import sys
import zlib
from datetime import datetime, timezone
from urllib import error, request

ENDPOINT = "https://api.openai.com/v1/images/generations"
MODELS = {
    "gpt-image-2.5-sunburst", "gpt-image-2.5-flare",
    "gpt-image-2.5-sunburst-2026-09-08",
    "gpt-image-2.5-flare-2026-09-08",
}
QUALITIES = {"low", "medium", "high", "xhigh", "max"}


def stamp():
    return datetime.now(timezone.utc).isoformat()


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False).encode()).hexdigest()


def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temp.replace(path)


def png_dimensions(data):
    if len(data) < 33 or data[:8] != b"\x89PNG\r\n\x1a\n" or data[12:16] != b"IHDR":
        raise ValueError("Provider response is not a PNG with an IHDR header")
    offset = 8
    found_end = False
    while offset + 12 <= len(data):
        length = struct.unpack(">I", data[offset:offset + 4])[0]
        end = offset + 12 + length
        if end > len(data):
            raise ValueError("Truncated PNG chunk")
        body = data[offset + 4:offset + 8 + length]
        stored_crc = struct.unpack(">I", data[offset + 8 + length:end])[0]
        if zlib.crc32(body) & 0xffffffff != stored_crc:
            raise ValueError("PNG chunk checksum mismatch")
        offset = end
        if body[:4] == b"IEND":
            found_end = True
            break
    if not found_end:
        raise ValueError("PNG has no complete IEND chunk")
    return list(struct.unpack(">II", data[16:24]))


def load_plan(path):
    config = json.loads(path.read_text(encoding="utf-8"))
    if config.get("provider") != "openai":
        raise ValueError("This adapter only supports provider='openai'")
    model = config.get("model", "gpt-image-2.5-sunburst")
    quality = config.get("quality", "medium")
    size = config.get("size", "2048x1152")
    if model not in MODELS:
        raise ValueError("This adapter is pinned to documented GPT Image 2.5 model IDs; verify new models before extending it")
    if quality not in QUALITIES:
        raise ValueError("Use an explicit low/medium/high/xhigh/max quality for predictable budgeting")
    match = re.fullmatch(r"(\d+)x(\d+)", size)
    if not match:
        raise ValueError("size must be explicit WIDTHxHEIGHT, for example 2048x1152")
    w, h = map(int, match.groups())
    if min(w, h) <= 0 or w % 16 or h % 16 or max(w, h) > 3840 or max(w, h) > 3 * min(w, h) or not 655360 <= w * h <= 8294400:
        raise ValueError("Size exceeds the adapter's conservative documented pixel/edge limits")
    attempts = config.get("max_attempts_per_scene", 2)
    if isinstance(attempts, bool) or not isinstance(attempts, int) or attempts < 1:
        raise ValueError("max_attempts_per_scene must be a positive integer")
    jobs = config.get("jobs")
    if not isinstance(jobs, list) or not jobs:
        raise ValueError("jobs must be a nonempty list")
    ids, paths, planned = set(), set(), []
    root = path.parent.resolve()
    for job in jobs:
        scene = job.get("scene_id", "")
        prompt = job.get("image_prompt", "")
        rel = Path(job.get("output_image", ""))
        if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}", scene) or scene in ids:
            raise ValueError("scene_id must be unique, 1-64 ASCII letters/digits/_/-")
        if not isinstance(prompt, str) or not prompt.strip() or len(prompt) > 32000:
            raise ValueError(f"{scene}: image_prompt must contain 1-32000 characters")
        out = (root / rel).resolve()
        if rel.is_absolute() or not out.is_relative_to(root) or out.suffix.lower() != ".png" or out in paths:
            raise ValueError(f"{scene}: output_image must be a unique relative .png path inside the job directory")
        ids.add(scene); paths.add(out)
        payload = {"model": model, "prompt": prompt, "size": size,
                   "quality": quality, "n": 1, "output_format": "png"}
        planned.append({"scene_id": scene, "output_image": str(rel),
                        "output_path": out, "payload": payload,
                        "request_hash": digest(payload)})
    return config, planned


def run(args):
    jobs_path = args.jobs.resolve()
    config, jobs = load_plan(jobs_path)
    ledger_path = (args.ledger or jobs_path.with_name("image_generation_ledger.json")).resolve()
    ledger = json.loads(ledger_path.read_text()) if ledger_path.exists() else {
        "provider": "openai", "endpoint": ENDPOINT, "attempts": [],
        "cost_note": "USD ceiling reserved per submitted request; not actual provider billing",
    }
    if ledger.get("provider") != "openai" or not isinstance(ledger.get("attempts"), list):
        raise ValueError("Incompatible ledger; use a dedicated ledger for this adapter")
    planned = []
    for job in jobs:
        previous = [x for x in ledger["attempts"] if x["scene_id"] == job["scene_id"]]
        successful = [x for x in previous if x["status"] == "succeeded" and x["request_hash"] == job["request_hash"]]
        if successful and job["output_path"].exists():
            if hashlib.sha256(job["output_path"].read_bytes()).hexdigest() != successful[-1]["sha256"]:
                raise ValueError(f"{job['scene_id']}: existing file differs from ledger; keep it and choose a new output path")
            continue
        if job["output_path"].exists():
            raise ValueError(f"{job['scene_id']}: refusing to overwrite an unverified existing output")
        if any(x["status"] in {"submitting", "unknown"} for x in previous):
            raise ValueError(f"{job['scene_id']}: unresolved previous request; inspect provider history before any paid retry")
        if len(previous) >= config.get("max_attempts_per_scene", 2):
            raise ValueError(f"{job['scene_id']}: max_attempts_per_scene reached")
        if previous and not args.retry_failed:
            raise ValueError(f"{job['scene_id']}: previous failure; inspect ledger, then explicitly use --retry-failed")
        planned.append((job, len(previous) + 1))
    report = {"mode": "execute" if args.execute else "dry-run", "endpoint": ENDPOINT,
              "model": jobs[0]["payload"]["model"], "size": jobs[0]["payload"]["size"],
              "quality": jobs[0]["payload"]["quality"], "planned_requests": len(planned),
              "already_complete": len(jobs) - len(planned),
              "outputs": [j["output_image"] for j, _ in planned]}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not args.execute or not planned:
        return 0
    if config.get("paid_generation_approved") is not True:
        raise ValueError("Execution needs paid_generation_approved:true based on the user's authorization")
    budget = config.get("budget_usd")
    ceiling = config.get("cost_ceiling_usd_per_request")
    if isinstance(budget, bool) or isinstance(ceiling, bool) or not isinstance(budget, (int, float)) or not isinstance(ceiling, (int, float)) or not math.isfinite(budget) or not math.isfinite(ceiling) or not 0 < ceiling <= budget:
        raise ValueError("Execution needs positive budget_usd and a verified cost_ceiling_usd_per_request within that budget")
    reserved = sum(float(x.get("reserved_usd", 0)) for x in ledger["attempts"])
    if reserved + len(planned) * ceiling > budget + 1e-9:
        raise ValueError("Planned conservative reservations exceed budget_usd; reduce the batch or obtain a higher authorized budget")
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        raise ValueError("OPENAI_API_KEY is not set locally; never paste the key into chat")
    for job, attempt in planned:
        entry = {"scene_id": job["scene_id"], "attempt": attempt, "status": "submitting",
                 "request_hash": job["request_hash"], "model": job["payload"]["model"],
                 "size": job["payload"]["size"], "quality": job["payload"]["quality"],
                 "output_image": job["output_image"], "submitted_at": stamp(),
                 "reserved_usd": ceiling}
        ledger["attempts"].append(entry); save_json(ledger_path, ledger)
        req = request.Request(ENDPOINT, data=json.dumps(job["payload"]).encode(), method="POST",
                              headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"})
        try:
            with request.urlopen(req, timeout=args.timeout) as response:
                entry["request_id"] = response.headers.get("x-request-id")
                result = json.load(response)
            data = base64.b64decode(result["data"][0]["b64_json"], validate=True)
            dimensions = png_dimensions(data)
            job["output_path"].parent.mkdir(parents=True, exist_ok=True)
            # Exclusive write; never silently replace an output produced elsewhere.
            with job["output_path"].open("xb") as handle:
                handle.write(data)
            entry.update(status="succeeded", completed_at=stamp(), actual_dimensions=dimensions,
                         bytes=len(data), sha256=hashlib.sha256(data).hexdigest(), usage=result.get("usage"))
            save_json(ledger_path, ledger)
            print(json.dumps({"scene_id": job["scene_id"], "status": "succeeded",
                              "path": job["output_image"], "dimensions": dimensions}))
        except error.HTTPError as exc:
            # A server error might have happened after submission. Do not blindly retry.
            entry.update(status="failed" if 400 <= exc.code < 500 else "unknown",
                         http_status=exc.code, request_id=exc.headers.get("x-request-id"), ended_at=stamp())
            save_json(ledger_path, ledger)
            print(f"Stopped at {job['scene_id']}: HTTP {exc.code}; inspect the ledger/provider account before retrying.", file=sys.stderr)
            return 2
        except Exception as exc:
            entry.update(status="unknown", error_type=type(exc).__name__, ended_at=stamp())
            save_json(ledger_path, ledger)
            # Do not echo raw exception content, request bodies, response bodies, or keys.
            print(f"Stopped at {job['scene_id']}: result is unresolved ({type(exc).__name__}); no automatic retry.", file=sys.stderr)
            return 2
    return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("jobs", type=Path, help="JSON plan; output paths are relative to this file")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--dry-run", action="store_true", help="Validate and print the plan; no key/network required (default)")
    mode.add_argument("--execute", action="store_true", help="Submit paid requests after authorization and budget checks")
    parser.add_argument("--ledger", type=Path, help="Defaults beside the jobs file; retain it when resuming")
    parser.add_argument("--retry-failed", action="store_true", help="Explicitly retry known HTTP failures within the attempt and budget ceilings")
    parser.add_argument("--timeout", type=float, default=900, help="Per-request network timeout in seconds")
    args = parser.parse_args()
    if args.timeout <= 0:
        parser.error("timeout must be positive")
    try:
        return run(args)
    except (ValueError, OSError, KeyError, TypeError, json.JSONDecodeError) as exc:
        print("Error: " + str(exc), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
