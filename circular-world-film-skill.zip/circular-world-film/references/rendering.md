# Portable editing CLI

Requirements: Python3.10+, Pillow, NumPy, and a normal FFmpeg/ffprobe installation with libx264. Discover executables through PATH or pass `--ffmpeg` and `--ffprobe`; no macOS application path is required. The package includes approved default title artwork, not proprietary font programs.

Run from the skill directory (or use the script's full path). Install the Python requirements in the user's usual environment/venv if absent; do not silently change unrelated environments.

```sh
python -m pip install -r requirements.txt
python scripts/film.py init --project /path/to/project --mode stills
```

`init` creates a37-scene `job.json`, project folders, and a local copy of the default original reference music at `audio/reference-score.m4a`. Copy `templates/brief.json` and `templates/scene-bank.json` to the project; fill the concept, actual subjects and provider choices before generating:

```sh
python scripts/prepare_prompts.py --brief /path/to/project/brief.json --bank /path/to/project/scene-bank.json --project /path/to/project
```

This writes all image/video prompts at once and updates the initialized render job's subjects, copy, mode and paths. It does **not** invent a culture, generate images, download references, spend money or submit videos. User-provided images are omitted from new image jobs. In the video route, an already supplied complete video skips both new image and video generation for that scene. An external video adapter should use the resolved image path in `job.json` when it differs from `images/sceneNN.png`. For I2V, approve/normalize the actual first frame before submission.

`brief_status` is `draft` while exploring concepts, and `ready` once the agent has resolved the brief using the user's instructions. It is a work-state marker, not a mandatory extra approval question. Draft batches never inherit paid-generation authorization. Use placeholder default copy for a concept-only draft and label it as provisional; resolve wording before the final render.

`audio_source` defaults to `reference`, which selects the bundled original music at offset0. For a replacement, set `audio_source` to `custom`, supply `audio_path` relative to the project (or absolute), and set `audio_offset_s`. Keeping the default needs no additional music upload.

## Job fields

```json
{
  "mode": "video",
  "copy": ["Within", "every form", "a universe", "咫尺之间", "万象自生"],
  "fonts": {"latin": null, "cjk": null},
  "audio": {"path": "audio/reference-score.m4a", "start_offset_seconds": 0, "source": "reference"},
  "scenes": [
    {
      "scene_id": "scene01", "subject": "chosen opening and closing world",
      "image": "images/scene01.png", "video": "videos/scene01.mp4",
      "source_offset_seconds": 0,
      "zoom_start": 1.0, "zoom_end": 1.025,
      "video_zoom": 1.0, "anchor": [0.5, 0.52], "polarity": "template"
    }
  ],
  "shot_overrides": {"38": {"source_offset_seconds": 0}}
}
```

The example shows one scene for readability; a real job must contain exactly scene01..scene37. Paths resolve relative to the job. `anchor` is the normalized crop/zoom center, not an automatic detector of the depicted horizon. Visually reframe a poor source; a zoom cannot repair the wrong geometry. `polarity` accepts `template`, `ivory` or `ink`.

Timing metadata may retain `example_subject` from the reference film. It is a reference label only; the new film's actual subject is `framing.subject` in the edit plan and `subject` in the project scene bank. Draft/copy-option status travels with the render job; review the brief before treating proposed words as final.

`stills` uses image files and gentle anchor-centered zoom. `video` uses the corresponding clips and their clean offsets. Both use the same timeline and title clock. Scene01 must have at least a4.08-second clean video window for the closing shot; use a supported≥5-second generation. Other source offsets must also leave enough frames. No implicit freeze-frame padding.

For changed wording, set appropriate font files in `fonts`. Latin reference: Georgia Regular; closing reference: original Songti. Default text uses the supplied25 RGBA assets. Custom text requires a real renderable font; a missing one is an explicit error. Preview new words to ensure readable optical size and no overlap. Fonts and generated captions are not interchangeable.

Alternatively, `title_overlays` can map shot keys such as `"15"` to a local 1920×1080 RGBA title artwork path and `"closing1"` / `"closing2"` to tightly cropped RGBA ending tiles. Use this only for reviewed supplied/custom lettering; preserve the template's optical sizes and baseline. The renderer scales supplied artwork to the export size.

## Plan, render, verify

```sh
python scripts/film.py plan --job /path/to/project/job.json --output /path/to/project/review/edit-plan.json --require-media
python scripts/film.py render --job /path/to/project/job.json --output /path/to/project/exports/final.mp4
python scripts/film.py verify --video /path/to/project/exports/final.mp4 --manifest /path/to/project/exports/final_work/render_manifest.json --output /path/to/project/review/validation.json
```

For a fast actual preview, add `--width 640 --height 360`; keep25fps and502frames. If music is not available, `render ... --silent-preview` creates an explicitly identified silent preview. Do not call that the final sound version. Source clip audio is discarded; only `job.audio` is mixed.

Expected main program:1920×1080, H.264, yuv420p,25fps,502frames,20.08s; delivered audio when provided. Use a new output path to preserve prior approved versions. The render manifest records each input, offset, zoom/anchor, frame interval and title assets so another editor/agent can rebuild the result.

Verification checks the encoded program and manifest, not whether a culture was represented well or a material moved naturally. Review all scenes and actual cut windows separately. A different music track must be arranged to the fixed cue map. The exact timeline in `assets/timeline.json` is normative; do not re-derive it by floating-point duration rounding or montage auto-editing.

## Other editors

If an agent uses an NLE, Remotion, ChatCut or another rendering stack, import the same frame intervals at25fps. Put each subject in its assigned slot, reuse scene01 only at the close, apply the supplied alpha titles and the measured closing keyframes, then verify the encoded output against the same502-frame contract. The included CLI is the reference implementation and portable fallback, not a requirement to abandon an editor the user explicitly selected.
