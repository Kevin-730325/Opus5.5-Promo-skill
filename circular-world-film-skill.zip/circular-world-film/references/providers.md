# Generation providers and portable hand-off

Verified 2026-10-27. Provider names, model IDs, quotas and price tiers change; inspect the current tool schema or linked official documentation before a live run. A connector being described here does not mean it is installed in the current agent.

## Choose a real capability

Use the user's selected provider when available. Otherwise prefer:

1. A built-in image/video generation tool that returns the actual media.
2. An already connected MCP tool or provider CLI/API with the required model and an authorized account.
3. Computer/browser control of the user's chosen generation application.
4. A prompt-and-job hand-off package if this agent has no execution channel. State the missing capability; never call ungenerated placeholders “finished”.

API means a program sends a structured request to a service. CLI means running that program through a terminal command. MCP exposes callable tools to an agent through a common protocol. Computer control means operating the visible application's buttons and upload/download controls. These are access routes, not image models. [MCP introduction](https://github.com/modelcontextprotocol/docs/blob/main/introduction.mdx)

## Codex and GPT Image 2.5

Prefer Codex's built-in image generation where the current host provides it. Read its schema: do not invent a `model`, `size`, `quality`, or destination argument. The native tool in the source environment exposed no model selector, so its presence alone does **not** prove GPT Image 2.5 is the backend. Record `model: host-managed/undisclosed` when that is all the host reveals.

For a requirement that specifically needs GPT Image 2.5, use a channel that explicitly exposes it. The official Images API documents `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, with dated snapshots also available. The packaged adapter uses the official Images generation endpoint, one PNG per prompt, and explicit size and quality. [OpenAI Images API reference](https://developers.openai.com/api/reference/resources/images/methods/generate)

The native tool does not require an API key; the API route uses a separate API account and its billing. Follow the host's image skill for built-in calls. Do not silently switch provider/model to work around access errors. Inspect each image visually and save the actual file into the project, not merely a tool preview or temporary link.

## Packaged OpenAI API adapter

`scripts/openai_stills.py` is a Python 3.9+ standard-library command, not an installed MCP server. It performs text-to-image only; reference edits must use an actual image-edit capability. All `output_image` paths are relative to the jobs JSON and must stay inside its directory.

```json
{
  "provider": "openai",
  "model": "gpt-image-2.5-sunburst",
  "size": "2048x1152",
  "quality": "medium",
  "max_attempts_per_scene": 2,
  "paid_generation_approved": false,
  "budget_usd": null,
  "cost_ceiling_usd_per_request": null,
  "jobs": [
    {
      "scene_id": "scene01",
      "image_prompt": "The complete approved still-image prompt goes here.",
      "output_image": "images/scene01.png"
    }
  ]
}
```

```sh
python scripts/openai_stills.py /path/to/project/image_jobs.json --dry-run
python scripts/openai_stills.py /path/to/project/image_jobs.json --execute
```

The default is dry-run: no network request and no credential read. Execution requires `OPENAI_API_KEY` in the local environment, `paid_generation_approved: true`, and positive budget fields. The agent can set the approval field from the user's existing authorization; this is not a demand for another confirmation. If the account, spending ceiling or paid-generation permission is missing, resolve that specific gap before submission. Never paste keys in chat or put them in the package.

Call the adapter only when `image_jobs.json` contains new jobs and its provider/model/size have been resolved. If the user already supplied all required media, skip generation entirely and continue to review and editing.

Read current official pricing and calculate a conservative per-request ceiling that covers the selected model, size, quality and prompt input. `budget_usd` and `cost_ceiling_usd_per_request` gate this adapter's reservations, **not** the provider's actual invoice or account-level spending limit. If a valid upper bound cannot be established, stop at dry-run and ask for a known budget/channel. Do not insert a guessed price. [OpenAI image-generation cost guide](https://developers.openai.com/api/docs/guides/image-generation#cost-and-latency)

The adapter saves `image_generation_ledger.json` beside the plan. Keep it when resuming: successful matching files are skipped; existing unverified files are never overwritten. A timeout or ambiguous server failure is marked `unknown` and blocks retransmission until the agent reconciles provider history. Known HTTP failures require `--retry-failed`; attempts and conservative reservations still count toward the limits. HTTP responses and credentials are not dumped into the ledger. The ledger records request IDs, prompt hashes, actual dimensions, output hashes and returned usage.

The image API supports explicit `WIDTHxHEIGHT` and PNG output. The adapter deliberately restricts its model IDs to the documented 2.5 variants and uses explicit quality so a cost ceiling can be planned. It does not send legacy `response_format`, force transparency, or claim that the chosen model is accessible to every account. Check live availability before paid work. [Images API parameters](https://developers.openai.com/api/reference/resources/images/methods/generate)

## Other image routes

| Provider/channel | Verified route | Practical mapping |
|---|---|---|
| Gemini / Nano Banana | Official Gemini API image-generation guide; discover the current image model | Map the still prompt plus image-reference inputs; set `aspectRatio: "16:9"` and supported resolution through the documented image config. Save returned image bytes. [Official guide](https://ai.google.dev/gemini-api/docs/image-generation) |
| FLUX / Black Forest Labs | Official BFL API, for example `POST https://api.bfl.ai/v1/flux-2-pro-preview` | Send prompt and documented dimensions. It is asynchronous: persist the returned task ID and use the returned `polling_url`, then save the completed image. Do not fabricate a polling address. [Official quickstart](https://docs.bfl.ai/quick_start/generating_images) |
| Lovart | Use an installed official integration if its actual tools support the task; otherwise the authenticated application | This package does not claim a verified public Lovart API/MCP. In the application, send the prepared prompt through its agent, inspect the produced image, then download the original. [Lovart](https://www.lovart.ai/) |
| Any other image model | Current official API/CLI/MCP or visible UI | Keep the composition/style prompt invariant, translate only supported parameter names, and record the actual provider/model/size. |

Do not confuse “no visible logo” with removal of provenance. Gemini documents SynthID in generated images; preserve provider provenance and obtain the platform's authorized original export rather than removing marks. [Gemini image guide](https://ai.google.dev/gemini-api/docs/image-generation)

## Video routes

The source workflow used image-to-video. For every approved still, submit it as the first frame with the scene's motion prompt. Generate a supported short duration long enough for the edit, then trim it to the **locked frame count** in the timeline. Provider duration choices never redefine the cut points. Disable generated audio when supported; otherwise discard it in the editor.

| Route | Verified entry point | Required capability |
|---|---|---|
| Kling | Official developer platform or its visible authenticated application | Image-to-video with first-frame input and downloadable result. Read the account's current API documentation rather than copying private web requests. [Kling developer platform](https://kling.ai/dev/api) |
| Runway API | `POST https://api.dev.runwayml.com/v1/image_to_video` | Map fields for the **chosen** model; the official API requires bearer authentication and the documented version header. Submit, retain task ID, poll its task endpoint, save completed output. Field support differs by model. [API reference](https://docs.dev.runwayml.com/api/) |
| Google video API | Current Gemini video guide | Discover the available model and first-frame pathway. Do not freeze an obsolete Veo preview ID into this skill. [Official guide](https://ai.google.dev/gemini-api/docs/video) |
| Other/host-native | Discover actual enabled generation tools | Require input-image support, bounded duration, job tracking and an original downloadable video. |

## Provider-neutral job contract

This is a hand-off contract, **not** a fictional universal API endpoint. An agent maps it to real exposed fields after inspecting the selected tool.

```json
{
  "scene_id": "scene01",
  "kind": "image_to_video",
  "input_image": "images/scene01.png",
  "motion_prompt": "The approved motion instruction for this scene.",
  "aspect_ratio": "16:9",
  "requested_resolution": "1080p",
  "requested_duration_seconds": 5,
  "target_edit_frames": 102,
  "target_fps": 25,
  "output_video": "videos/scene01.mp4"
}
```

For each real submission, append `provider`, actual `model`, `job_id`, `attempt`, `submitted_at`, actual parameters and status to a local ledger before moving on. Track `prepared → submitted → processing → downloaded → visually_accepted` separately. An agent may submit a prepared batch without waiting for each render, respecting the user's concurrency and spending ceiling. “Submitted” never means “finished”.

The normalized completed-media record is `scene_id`, local path, media kind, width, height, fps/frame count for video, provider/model, attempt, prompt hash, source task ID, and visual QA status. Download failures resume the same output; they are not new paid generations.

## Visible-UI fallback

Use only the agent's supported computer/browser tools. Read the current interface, choose the model and generation mode, set the supported ratio/resolution, paste the prepared prompt or upload the approved first frame, then submit and record visible success. Avoid simultaneous agents controlling one browser. Re-read the visible state after each mutation. Never extract cookies, session tokens or private network calls to invent an API.

Finish by downloading the original files, checking decode/identity/dimensions, and returning them to the local scene manifest. If UI control is interrupted, preserve the ledger and resume from the last verified task; do not keep clicking uncertain targets or resubmit unknown jobs.
