# Batch production and quality decisions

## Prepare before submitting

Resolve all37 scene concepts, write both prompt sets and allocate the shot roles first. Store prompts, local output names and attempts by `scene_id`. The first batch should test representative hard cases—liquid, rigid craft, architecture and light/dark caption backgrounds—without serially waiting on one complete image→video chain. Once the style is established, keep the queue moving within actual provider limits. A provider's submit response must be acknowledged before advancing the ledger.

The minimum useful provider record is:

```json
{"scene_id":"scene02","kind":"image","attempt":1,"provider":"actual service","model":"actual model or not exposed","status":"submitted","provider_job_id":"returned value","prompt_path":"prompts/scene02.txt","output_path":null,"quoted_cost":null,"cost_unit":null}
```

Use states `planned/submitted/running/completed/downloaded/reviewed/rejected/failed/unknown`. An unknown network response is not a failed generation. Query the recorded job or inspect the website before resubmission. Download the original asset rather than a browser screenshot or preview. Verify dimensions, file decode and scene identity; filenames or chronological order alone may mislabel downloads.

## Stills route

Inspect the still, normalize only framing/color as needed, and animate a gentle optical push-in about the circular anchor. Default zoom is modest (about1.00→1.035), not a large crop that destroys the horizon. Keep every cut's exact frame count, including the5–15-frame flashes. On a very short shot the motion may be subtle; do not increase it into a lunge merely to make a numeric motion score pass. Apply the same title pipeline and closing track.

## Image-to-video route

Upload the accepted clean still as first frame. Use the per-scene physical action plus these invariants: movement begins immediately, single continuous take, stable broad arc, exact material/palette, no extra objects/text, no morphing, no reveal of the entire object, no generated cuts or transitions. If a model adds audio, do not mix that incidental source audio into the final film.

Request a supported short duration long enough to select a clean interval. Most montage clips need only4–5s of source, but the shared opening/closing asset must cover the4.08s closing window plus its selected offset; request at least5s where available. Respect provider-specific allowed duration values rather than inventing “4s” if it is unavailable. Keep a uniform usable resolution/aspect ratio.

Inspect the full result, then choose the exact `video_offset_s` whose entire required window is clean. Check the actual excerpt, not just the first frame or a preview thumbnail. A rigid surface must not melt; a liquid should really diffuse or ripple. Unapproved windows, insufficient source duration or missing media should block the final video render with a precise error. Do not quietly freeze the end, loop the source, slow everything down, or insert a still to satisfy the502-frame count.

## Revision policy

The brief sets max attempts per subject and a budget. Before a second attempt, name the failure and change the prompt/reference accordingly. Preserve rejected sources for diagnosis; do not mix them into final media by accident. If a source remains poor, substitute a **different appropriate object in the same slot** while retaining palette, arc and duration. Seek a user choice only when the concept or spending decision materially changes.

## Sound

The package includes the original reference soundtrack as `assets/audio/reference-score.m4a`, extracted without audio re-encoding from the approved final film. Its20.08s program begins at0 and is the default for both routes. Do not shift it to a new first transient by guesswork. Custom music is optional: supply its path and explicit offset, then compose/edit it to the fixed cut clock if audible matching is required. Review onset, build, dense-cut passage and the16s closing release together with the images. Provenance and the source audio hash are in `assets/audio/manifest.json`.

## Delivery checks

Check file/probe metadata and visually inspect every scene. Distinguish main program video from an attached cover-art stream. Verify frame0, both sides of all37 internal boundaries, captions at each size change, frame400 and the last frame. Listen to the actual exported mix. Check no watermark, wrong crop, accidental subtitle generation, duplicated unrelated scene, black flash or delayed motion. A codec probe proves format/timing, not aesthetics or audio beat perception.

Keep `final.mp4`, resolved render job, exact timeline manifest, scene bank, full prompts, generation ledger and a contact sheet. Deliver a useful playable file and clearly name any incomplete step. Preserve the source media; do not overwrite the user's approved older film.
