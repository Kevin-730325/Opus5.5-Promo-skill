# Concept intake and cultural adaptation

Use the user's natural language. Gather missing essentials together, once. `templates/brief.md` is the short human form; `brief.json` records the resolved decisions. Do not ask for API vs MCP terminology: ask what image/video services the user can use, then discover the available route.

The original reference music is included and selected by default. Ask about music only if the user wants a replacement or a new soundtrack would materially support the concept.

## If there is no concept yet

Ask: **“你想让观众在这一圈之内看见什么：一种文化的日常、一种材料的生命，还是一个地方从微观到建筑的世界？”**

Offer three concrete directions tied to their stated subject. For a proposed Japanese theme, for example, directions could be “water and vessels”, “fiber and handwork”, or “everyday objects at microscopic scale”. These are concept options, not claims that all listed objects are unique to Japan. Ask region/period when that distinction changes the objects.

Turn the chosen direction into one sentence: “Within the same curved boundary, ____ changes scale/material/time while ____ remains.” Translate that into a scene progression and copy. If copy is absent, propose three linked short phrases plus two ending lines; keep each readable in its fixed short slot. Avoid packing a paragraph into the reference's large type.

## Build a material atlas

Build more candidates than the 37 final slots, then select for diversity and the locked color/rhythm roles. Use a table:

| scene_id | actual subject / local name | cultural or conceptual reason | macro detail | circular feature | dominant/background color | physical motion | source link / provided asset |
|---|---|---|---|---|---|---|---|
| scene02 | liquid or microscopic material | why it belongs | particles, meniscus, internal flow | shallow liquid edge | silver / near-black | low surface wave + internal diffusion | museum/science/user source |

Do not equate “a culture” with a handful of national emblems. Distribute the selections across appropriate categories: living tissue, liquid/mineral, plant/food, vessels, metal, textiles, print/paper, tools/games, architecture/settlements and atmosphere. These are candidate categories, not compulsory national checkboxes. Faith-related objects must be relevant and accurately described; do not combine unrelated iconography merely because it is circular.

## Transfer by function, not by literal substitution

- Reference ink → a culturally relevant genuine **liquid or pigment dispersion**, preserving a liquid meniscus and internal motion. A painted landscape is not equivalent to liquid.
- Reference celadon → a researched vessel/glaze tradition with subtle refraction and ceramic surface.
- Reference silk fan → a researched woven, stitched, paper or openwork circular object; preserve filament-scale detail.
- Reference coin → a real circular metal object's partial rim and patina. Keep actual hole geometry where relevant.
- Reference Temple of Heaven → a **local fragment of a circular eave or an aerial arc of a wall**, never an entire landmark postcard.
- Reference botanical section → plant microstructure selected for the concept; geography is optional if no defensible relation exists.
- Reference abacus/geometry → a culturally grounded counting/drawing/precision craft. A few controlled non-round exceptions are allowed; most slots must carry the arc.

For a Japanese brief, a research shortlist might include a tea-bowl lip, bamboo cross-section, a paper umbrella edge, a round lacquer tray, a drum skin, a ceramic glaze micrograph and a round opening. Check the particular place, period, material and source before treating it as a final scene. Generate close material views, not a collage of country symbols. Use the same method for any culture, region, scientific theme, industry or invented material world.

## Resolve before spending

Resolve the desired route, whether new generation is authorized, available providers, output folder and a meaningful budget/attempt cap. Reuse authorization already given. A service being logged in is not itself a spending instruction; a user explicitly asking to generate within a stated budget is. If the user only wants prompts, stop at that deliverable and do not submit paid jobs.

Default visual format is 16:9 landscape, finished at 1920×1080/25 fps. Request native stills at least this large when supported. Record actual dimensions and model backend. A 9:16 or 3:4 cover is a separate layout; it must not silently change the film template.
