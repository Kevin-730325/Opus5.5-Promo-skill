# Locked visual and typographic language

Open `assets/reference/approved-film-preview.mp4` and `assets/reference/contact-sheet.jpg` before designing a new culture. The preview preserves the approved edit and audio at a compact resolution; the contact sheet shows its material/color sequence. These are from the approved film, not a fresh model test.

## One shape, many materials

The recurring anchor is an oversized **broad, shallow convex arc**. Center its apex near x=50%, y=52–55%; the sides descend toward approximately 65–75%. Material continues beyond left, right and bottom. The upper 40–50% is a quiet field for breathing space and type. These are source-image targets; final framing must be judged against the reference, not blindly forced on a bad source.

Use a low/tangent macro camera, a telephoto crop or an appropriate overhead macro. Show only a chosen part of an object. A landscape-like horizon can be a cell membrane, liquid meniscus, porcelain rim, tree ring, textile edge or architectural cornice. Do not turn every subject into a centered sphere or show the whole tourist landmark. The mathematical/drawing and counting-device slots are deliberate exceptions, not permission for arbitrary square images.

## Material and color

- High material credibility: skin pores, irregular cell walls, wet refraction, imperfect glaze, metal patina, tool marks, fibers and worn pigment.
- Controlled raking light and tactile depth; restrained halation, fine analog grain, slightly imperfect photographic/printed color. Avoid sterile product-render gloss, neon sci-fi light ribbons, heavy grunge or an oil-painting filter on everything.
- Preserve variety: black/cold blue → bright material contrast → cream/red/cobalt/pink/mustard/jade alternation. The fast passage changes **material and color**, not just recolors the same object.
- One materially plausible action per generated video: internal diffusion, surface tension, refractive highlight slide, fabric/filament movement, rigid parallax or controlled bead displacement. Keep the upper negative space quiet.
- Match the starting and ending scene; most other subjects appear once. Do not fill a shortfall by repeatedly recycling attractive shots.

## Typography

The approved Latin face is **Georgia Regular**; the ending uses the original Songti rendering. Default copy is shipped as RGBA artwork, so the default render does not require distributing these fonts. For new wording, obtain a locally installed or user-supplied appropriate font file. A fallback typeface requires visual review and must not be represented as pixel-identical to the original.

The recipe is deliberately specific:

1. Rasterize at 3×, downsample for refined edges.
2. Stable per-title ink distress: sparse tiny dropouts/dim ink, plus low-frequency uneven density. Text texture does **not** flicker per video frame.
3. Bend the baseline: outer columns lower, central columns higher; bend amplitude about 3.1% of word width, minimum 4 pixels at 1080p.
4. Center the type and hold its lower extent around y=530 in the 1920×1080 composition. Keep a small clean gap above the material edge.
5. Begin captions at frame219 (8.76s). The three phases grow over successive cuts: `Within`, `every form`, `a universe`. The exact slot-specific artwork/size is in the lock and title assets; do not substitute a continuous software zoom for the stepped type progression.
6. Use warm ivory on dark fields or near-black ink on light fields. Change RGB polarity when needed; preserve alpha geometry and texture. No outline, drop shadow, rounded box, modern UI label or glowing type.

Custom text remains in three phases plus two ending phrases. Shorten copy rather than overflow into the material. Non-Latin copy needs an optically appropriate serif/print tradition and a preview, not an automatic literal font substitution. Preserve the user's chosen language; the original English should remain when requested.

## Ending and fixed clock

The closing shot begins at frame400 /16.00s and lasts102frames. It reuses the opening scene with the reference's upward editorial movement and two closing phrases. The rising material/background and title positions are a measured track in the lock, not an improvised fade-out. The full video is502frames at25fps=20.08s; first picture timing already includes the historical audio alignment. Do not “correct” it to20.00s.

Picture grain and title distress are separate. Grain may vary per frame; title ink should stay stable. In the source edit, montage picture grain is approximatelyσ2.1/255 and closing grainσ1.25/255. These are subtle finishing amounts, not a substitute for convincing source material or actual motion.
